"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useTheme } from "next-themes"
import type { UserPreferences } from "@/types/widget"
import { updateUserPreferences, getUserPreferences } from "@/app/dashboard/widgets/actions"
import { Paintbrush, Layout, Type, Sliders, Box } from "lucide-react"
import { toast } from "@/components/ui/use-toast"

export function EnhancedCustomizationPanel() {
  const { theme, setTheme } = useTheme()
  const [preferences, setPreferences] = useState<UserPreferences>({
    theme: "system",
    accent_color: "#6d28d9",
    font_size: "medium",
    animation_level: "medium",
    border_radius: "medium",
    layout_density: "comfortable",
  })
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    const loadPreferences = async () => {
      const userPrefs = await getUserPreferences()
      if (userPrefs) {
        setPreferences({
          ...preferences,
          ...userPrefs,
          theme: theme as "light" | "dark" | "system",
        })
      }
    }

    loadPreferences()
  }, [theme])

  const handleThemeChange = (newTheme: string) => {
    setTheme(newTheme)
    setPreferences({ ...preferences, theme: newTheme as "light" | "dark" | "system" })
  }

  const handlePreferenceChange = (key: keyof UserPreferences, value: any) => {
    setPreferences({ ...preferences, [key]: value })
  }

  const savePreferences = async () => {
    setLoading(true)
    try {
      await updateUserPreferences({
        ...preferences,
        theme: preferences.theme || theme,
      })
      toast({
        title: "Preferences saved",
        description: "Your customization preferences have been updated.",
      })
    } catch (error) {
      console.error("Error saving preferences:", error)
      toast({
        title: "Error saving preferences",
        description: "There was a problem saving your preferences.",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const accentColors = [
    { name: "Purple", value: "#6d28d9" },
    { name: "Blue", value: "#2563eb" },
    { name: "Green", value: "#16a34a" },
    { name: "Red", value: "#dc2626" },
    { name: "Orange", value: "#ea580c" },
    { name: "Pink", value: "#db2777" },
    { name: "Teal", value: "#0d9488" },
    { name: "Indigo", value: "#4f46e5" },
  ]

  return (
    <Card className="w-full max-w-4xl mx-auto">
      <CardHeader>
        <CardTitle>Customize Your Experience</CardTitle>
        <CardDescription>Personalize your dashboard with these customization options</CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="theme">
          <TabsList className="grid grid-cols-5 mb-4">
            <TabsTrigger value="theme" className="flex items-center gap-2">
              <Paintbrush className="h-4 w-4" />
              <span className="hidden sm:inline">Theme</span>
            </TabsTrigger>
            <TabsTrigger value="layout" className="flex items-center gap-2">
              <Layout className="h-4 w-4" />
              <span className="hidden sm:inline">Layout</span>
            </TabsTrigger>
            <TabsTrigger value="typography" className="flex items-center gap-2">
              <Type className="h-4 w-4" />
              <span className="hidden sm:inline">Typography</span>
            </TabsTrigger>
            <TabsTrigger value="animations" className="flex items-center gap-2">
              <Sliders className="h-4 w-4" />
              <span className="hidden sm:inline">Animations</span>
            </TabsTrigger>
            <TabsTrigger value="components" className="flex items-center gap-2">
              <Box className="h-4 w-4" />
              <span className="hidden sm:inline">Components</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="theme" className="space-y-4">
            <div className="space-y-4">
              <div>
                <Label>Color Theme</Label>
                <RadioGroup
                  defaultValue={preferences.theme}
                  value={preferences.theme}
                  onValueChange={(value) => handleThemeChange(value)}
                  className="flex space-x-2 mt-2"
                >
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="light" id="light" />
                    <Label htmlFor="light">Light</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="dark" id="dark" />
                    <Label htmlFor="dark">Dark</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="system" id="system" />
                    <Label htmlFor="system">System</Label>
                  </div>
                </RadioGroup>
              </div>

              <div>
                <Label>Accent Color</Label>
                <div className="grid grid-cols-4 gap-2 mt-2">
                  {accentColors.map((color) => (
                    <Button
                      key={color.value}
                      type="button"
                      variant={preferences.accent_color === color.value ? "default" : "outline"}
                      className="relative h-8 w-full"
                      style={{
                        backgroundColor: preferences.accent_color === color.value ? color.value : "transparent",
                        borderColor: color.value,
                        color: preferences.accent_color === color.value ? "white" : "inherit",
                      }}
                      onClick={() => handlePreferenceChange("accent_color", color.value)}
                    >
                      <span className="absolute inset-0 flex items-center justify-center">
                        {preferences.accent_color === color.value && "✓"}
                      </span>
                      <span className="sr-only">{color.name}</span>
                    </Button>
                  ))}
                </div>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="layout" className="space-y-4">
            <div>
              <Label>Layout Density</Label>
              <Select
                value={preferences.layout_density}
                onValueChange={(value) => handlePreferenceChange("layout_density", value)}
              >
                <SelectTrigger className="mt-2">
                  <SelectValue placeholder="Select density" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="compact">Compact</SelectItem>
                  <SelectItem value="comfortable">Comfortable</SelectItem>
                  <SelectItem value="spacious">Spacious</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </TabsContent>

          <TabsContent value="typography" className="space-y-4">
            <div>
              <Label>Font Size</Label>
              <Select
                value={preferences.font_size}
                onValueChange={(value) => handlePreferenceChange("font_size", value)}
              >
                <SelectTrigger className="mt-2">
                  <SelectValue placeholder="Select font size" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="small">Small</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="large">Large</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </TabsContent>

          <TabsContent value="animations" className="space-y-4">
            <div>
              <Label>Animation Level</Label>
              <Select
                value={preferences.animation_level}
                onValueChange={(value) => handlePreferenceChange("animation_level", value)}
              >
                <SelectTrigger className="mt-2">
                  <SelectValue placeholder="Select animation level" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">None</SelectItem>
                  <SelectItem value="minimal">Minimal</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </TabsContent>

          <TabsContent value="components" className="space-y-4">
            <div>
              <Label>Border Radius</Label>
              <Select
                value={preferences.border_radius}
                onValueChange={(value) => handlePreferenceChange("border_radius", value)}
              >
                <SelectTrigger className="mt-2">
                  <SelectValue placeholder="Select border radius" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">None</SelectItem>
                  <SelectItem value="small">Small</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="large">Large</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
      <CardFooter className="flex justify-between">
        <Button
          variant="outline"
          onClick={() =>
            setPreferences({
              theme: "system",
              accent_color: "#6d28d9",
              font_size: "medium",
              animation_level: "medium",
              border_radius: "medium",
              layout_density: "comfortable",
            })
          }
        >
          Reset to Default
        </Button>
        <Button onClick={savePreferences} disabled={loading}>
          {loading ? "Saving..." : "Save Preferences"}
        </Button>
      </CardFooter>
    </Card>
  )
}
