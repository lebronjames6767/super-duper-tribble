"use client"

import type React from "react"

import { useScrollAnimation, getAnimationClasses, type AnimationStyle } from "@/hooks/use-animations"

interface ScrollRevealProps {
  children: React.ReactNode
  delay?: number
  className?: string
  animation?: AnimationStyle
}

export const ScrollReveal = ({ children, delay = 0, className = "", animation = "fade-up" }: ScrollRevealProps) => {
  const { ref, isVisible } = useScrollAnimation()

  return (
    <div
      ref={ref}
      className={`${getAnimationClasses(animation, isVisible)} ${className}`}
      style={{ transitionDelay: `${delay}ms` }}
    >
      {children}
    </div>
  )
}
