"use client"

import { useState, useEffect } from "react"
import { Bell } from "lucide-react"
import { Button } from "@/components/ui/button"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { motion, AnimatePresence } from "framer-motion"
import { useRouter } from "next/navigation"
import { useNotifications } from "@/context/notification-context"

export function NotificationBell() {
  const router = useRouter()
  const { notifications, markAsRead } = useNotifications()
  const [isOpen, setIsOpen] = useState(false)
  const [hasNewNotifications, setHasNewNotifications] = useState(false)
  const [notificationCount, setNotificationCount] = useState(0)

  useEffect(() => {
    // Count unread notifications
    const unreadCount = notifications.filter((n) => !n.read).length
    setNotificationCount(unreadCount)
    setHasNewNotifications(unreadCount > 0)
  }, [notifications])

  const handleNotificationClick = (notification) => {
    markAsRead(notification.id)

    // Navigate based on notification type
    if (notification.type === "assignment") {
      router.push("/dashboard/assignments")
    } else if (notification.type === "reward") {
      router.push("/dashboard/rewards")
    } else if (notification.type === "milestone") {
      router.push("/dashboard/goals")
    } else {
      router.push("/dashboard/notifications")
    }

    setIsOpen(false)
  }

  return (
    <DropdownMenu open={isOpen} onOpenChange={setIsOpen}>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="icon" className="relative text-gray-400 hover:text-white">
          <Bell className="h-5 w-5" />
          <AnimatePresence>
            {hasNewNotifications && (
              <motion.div
                className="absolute -right-1 -top-1 flex h-5 w-5 items-center justify-center rounded-full bg-gradient-to-r from-[#08efb5] to-purple-600 text-xs font-bold text-black"
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                exit={{ scale: 0 }}
                transition={{ type: "spring", stiffness: 500, damping: 30 }}
              >
                {notificationCount > 9 ? "9+" : notificationCount}
              </motion.div>
            )}
          </AnimatePresence>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-80 border-gray-700 bg-gray-800/90 backdrop-blur-md">
        <div className="flex items-center justify-between border-b border-gray-700 p-4">
          <h4 className="text-sm font-medium text-white">Notifications</h4>
          <Button
            variant="ghost"
            size="xs"
            className="text-xs text-gray-400 hover:text-white"
            onClick={() => router.push("/dashboard/notifications")}
          >
            View All
          </Button>
        </div>

        <div className="max-h-[300px] overflow-y-auto scrollbar-thin">
          {notifications.length === 0 ? (
            <div className="flex flex-col items-center justify-center p-6 text-center">
              <Bell className="mb-2 h-10 w-10 text-gray-600" />
              <p className="text-gray-400">No notifications yet</p>
              <p className="mt-1 text-xs text-gray-500">Notifications will appear here</p>
            </div>
          ) : (
            notifications.slice(0, 5).map((notification) => (
              <DropdownMenuItem
                key={notification.id}
                className={`flex cursor-pointer flex-col items-start border-b border-gray-700 p-4 last:border-0 ${
                  notification.read ? "opacity-70" : "bg-gray-700/30"
                }`}
                onClick={() => handleNotificationClick(notification)}
              >
                <div className="flex w-full items-start justify-between">
                  <span className="font-medium text-white">{notification.title}</span>
                  {!notification.read && <span className="ml-2 h-2 w-2 rounded-full bg-[#08efb5]"></span>}
                </div>
                <p className="mt-1 text-sm text-gray-400">{notification.message}</p>
                <span className="mt-2 text-xs text-gray-500">
                  {new Date(notification.timestamp).toLocaleTimeString([], {
                    hour: "2-digit",
                    minute: "2-digit",
                  })}
                </span>
              </DropdownMenuItem>
            ))
          )}
        </div>
      </DropdownMenuContent>
    </DropdownMenu>
  )
}
