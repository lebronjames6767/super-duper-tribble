"use client"

import { useEffect, useState } from "react"
import { getBrowserClient } from "@/lib/supabase"
import { useAuth } from "@/context/auth-context"
import { useToast } from "@/components/ui/use-toast"

// Define the activities that require rewards
const RESTRICTED_ACTIVITIES = {
  SOCIAL_MEDIA: "social_media",
  GAMING: "gaming",
  STREAMING: "streaming",
  MUSIC: "music",
}

// Map reward names to activities they unlock
const REWARD_TO_ACTIVITY_MAP = {
  "Social Media Break": RESTRICTED_ACTIVITIES.SOCIAL_MEDIA,
  "Gaming Break": RESTRICTED_ACTIVITIES.GAMING,
  "Streaming Break": RESTRICTED_ACTIVITIES.STREAMING,
  "Music Break": RESTRICTED_ACTIVITIES.MUSIC,
}

// Pages that should never be restricted
const UNRESTRICTED_PAGES = [
  "/dashboard",
  "/dashboard/assignments",
  "/dashboard/rewards",
  "/dashboard/settings",
  "/dashboard/analytics",
  "/dashboard/schedule",
]

export function RewardEnforcer({ children, activity }) {
  const { user } = useAuth()
  const [isAllowed, setIsAllowed] = useState(true) // Default to allowed
  const [isLoading, setIsLoading] = useState(true)
  const [initialized, setInitialized] = useState(false)
  const { toast } = useToast()
  const supabase = getBrowserClient()

  useEffect(() => {
    // Check if we're on an unrestricted page
    if (typeof window !== "undefined") {
      const currentPath = window.location.pathname
      const isUnrestrictedPage = UNRESTRICTED_PAGES.some((page) => currentPath.startsWith(page))

      if (isUnrestrictedPage || !activity) {
        // Skip restriction check for unrestricted pages or when no activity is specified
        setIsAllowed(true)
        setIsLoading(false)
        return
      }

      // Only check for rewards if we're on a restricted page and an activity is specified
      checkForActiveRewards()
    }
  }, [user, activity])

  // Check if the user has an active reward for this activity
  const checkForActiveRewards = async () => {
    if (!user || !activity) {
      setIsAllowed(true) // Default to allowed if no user or activity
      setIsLoading(false)
      return
    }

    try {
      // Add a small delay to ensure Supabase client is ready
      if (!initialized) {
        await new Promise((resolve) => setTimeout(resolve, 500))
        setInitialized(true)
      }

      // Query for active rewards
      const { data: userRewards, error } = await supabase
        .from("user_rewards")
        .select(`
          id,
          user_id,
          reward_id,
          redeemed_at,
          is_used,
          active_until,
          rewards (
            id,
            name,
            description,
            cost
          )
        `)
        .eq("user_id", user.id)
        .eq("is_used", false)
        .gt("active_until", new Date().toISOString())

      if (error) {
        console.error("Error fetching active rewards:", error)
        // If there's an error, we'll assume the activity is allowed
        setIsAllowed(true)
        setIsLoading(false)
        return
      }

      // Check if any of the active rewards allow this activity
      const hasActiveReward = userRewards.some((userReward) => {
        // Get the reward name and description
        const rewardName = (userReward.rewards?.name || "").toLowerCase()
        const rewardDesc = (userReward.rewards?.description || "").toLowerCase()

        // Check if this reward unlocks the current activity
        return rewardName.includes(activity.toLowerCase()) || rewardDesc.includes(activity.toLowerCase())
      })

      setIsAllowed(hasActiveReward)
      setIsLoading(false)
    } catch (error) {
      console.error("Error checking rewards:", error)
      // If there's an error, we'll assume the activity is allowed
      setIsAllowed(true)
      setIsLoading(false)
    }
  }

  // If still loading, show a minimal loading indicator
  if (isLoading) {
    return <>{children}</>
  }

  // If allowed or no activity specified, show the children
  if (isAllowed || !activity) {
    return <>{children}</>
  }

  // Only show restriction UI if not allowed and an activity was specified
  return (
    <div className="flex h-full w-full flex-col items-center justify-center space-y-4 p-8 text-center">
      <div className="rounded-full bg-amber-500/20 p-4">
        <svg
          xmlns="http://www.w3.org/2000/svg"
          width="24"
          height="24"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
          className="h-8 w-8 text-amber-500"
        >
          <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10" />
        </svg>
      </div>
      <h2 className="text-xl font-bold text-white">Reward Required</h2>
      <p className="text-gray-400">
        You need to activate a {activity} reward to access this feature. Visit the rewards page to redeem and activate a
        reward.
      </p>
      <a
        href="/dashboard/rewards"
        className="inline-flex items-center justify-center rounded-md bg-[#08efb5] px-4 py-2 text-sm font-medium text-black transition-colors hover:bg-[#08efb5]/80"
      >
        Go to Rewards
      </a>
    </div>
  )
}
