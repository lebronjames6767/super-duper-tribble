"use client"

import { useState, useEffect } from "react"

export function Calendar({ assignments = [] }) {
  const [currentDate, setCurrentDate] = useState(new Date())
  const [calendarDays, setCalendarDays] = useState([])
  const [debugMode, setDebugMode] = useState(false)

  // Day names for formatting
  const DAYS_OF_WEEK = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"]
  const MONTHS = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December",
  ]

  // Format date: "January 2023"
  const formatMonthYear = (date) => {
    const monthName = MONTHS[date.getMonth()]
    const year = date.getFullYear()
    return `${monthName} ${year}`
  }

  // Format date: "1"
  const formatDay = (date) => {
    return date.getDate().toString()
  }

  // Generate calendar days whenever the month changes
  useEffect(() => {
    // Get first day of month
    const firstDay = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1)
    // Get last day of month
    const lastDay = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0)

    // Create array of all days in month
    const days = []
    for (let d = 1; d <= lastDay.getDate(); d++) {
      days.push(new Date(currentDate.getFullYear(), currentDate.getMonth(), d))
    }

    // Get the day of the week of the first day (0 = Sunday, 1 = Monday, etc.)
    const firstDayOfWeek = firstDay.getDay()

    // Add empty days at the beginning to align with the correct day of week
    const emptyDays = Array(firstDayOfWeek).fill(null)

    setCalendarDays([...emptyDays, ...days])
  }, [currentDate])

  // Navigate to previous month
  const prevMonth = () => {
    setCurrentDate((prev) => {
      const newDate = new Date(prev)
      newDate.setMonth(prev.getMonth() - 1)
      return newDate
    })
  }

  // Navigate to next month
  const nextMonth = () => {
    setCurrentDate((prev) => {
      const newDate = new Date(prev)
      newDate.setMonth(prev.getMonth() + 1)
      return newDate
    })
  }

  // Check if a day has assignments
  const getAssignmentsForDay = (day) => {
    if (!day || !assignments || !Array.isArray(assignments)) return []

    return assignments.filter((assignment) => {
      try {
        if (!assignment || !assignment.deadline) return false

        const deadlineDate = new Date(assignment.deadline)
        return isSameDay(deadlineDate, day)
      } catch (error) {
        console.error("Error checking assignment date:", error)
        return false
      }
    })
  }

  // Check if two dates are the same day
  const isSameDay = (date1, date2) => {
    return (
      date1.getDate() === date2.getDate() &&
      date1.getMonth() === date2.getMonth() &&
      date1.getFullYear() === date2.getFullYear()
    )
  }

  // Check if a date is in the current month
  const isSameMonth = (date1, date2) => {
    return date1.getMonth() === date2.getMonth() && date1.getFullYear() === date2.getFullYear()
  }

  // Check if a date is today
  const isToday = (date) => {
    const today = new Date()
    return isSameDay(date, today)
  }

  // Get color based on assignment size
  const getAssignmentColor = (size) => {
    switch (size?.toLowerCase()) {
      case "small":
        return "bg-green-500/20 text-green-300"
      case "large":
        return "bg-red-500/20 text-red-300"
      default: // medium
        return "bg-amber-500/20 text-amber-300"
    }
  }

  // Toggle debug mode
  const toggleDebugMode = () => {
    setDebugMode(!debugMode)
  }

  return (
    <div className="bg-gray-900 border border-gray-700 rounded-xl p-6 shadow-lg">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl font-bold bg-gradient-to-r from-teal-400 to-emerald-500 bg-clip-text text-transparent">
          {formatMonthYear(currentDate)}
        </h2>
        <div className="flex gap-2">
          <button
            onClick={prevMonth}
            className="p-2 rounded-lg bg-gray-800 hover:bg-gray-700 text-white transition-colors"
          >
            &larr;
          </button>
          <button
            onClick={() => setCurrentDate(new Date())}
            className="p-2 rounded-lg bg-gray-800 hover:bg-gray-700 text-white transition-colors"
          >
            Today
          </button>
          <button
            onClick={nextMonth}
            className="p-2 rounded-lg bg-gray-800 hover:bg-gray-700 text-white transition-colors"
          >
            &rarr;
          </button>
          <button
            onClick={toggleDebugMode}
            className="p-2 rounded-lg bg-gray-800 hover:bg-gray-700 text-white text-xs transition-colors"
          >
            {debugMode ? "Hide Debug" : "Debug"}
          </button>
        </div>
      </div>

      <div className="grid grid-cols-7 gap-1">
        {/* Day headers */}
        {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((day) => (
          <div key={day} className="text-center text-gray-400 font-medium py-2">
            {day}
          </div>
        ))}

        {/* Calendar days */}
        {calendarDays.map((day, index) => {
          if (!day) {
            // Empty day
            return <div key={`empty-${index}`} className="aspect-square p-1" />
          }

          const assignmentsForDay = getAssignmentsForDay(day)
          const isCurrentMonth = isSameMonth(day, currentDate)
          const isCurrentDay = isToday(day)

          return (
            <div key={day.toString()} className={`aspect-square p-1 ${!isCurrentMonth ? "opacity-40" : ""}`}>
              <div
                className={`h-full rounded-lg flex flex-col items-center justify-start p-1
                  ${isCurrentDay ? "ring-2 ring-teal-500 bg-gray-800" : "hover:bg-gray-800"}
                  ${assignmentsForDay.length > 0 ? "bg-gray-800/50" : ""}
                `}
              >
                <span
                  className={`
                  w-7 h-7 flex items-center justify-center rounded-full text-sm
                  ${isCurrentDay ? "bg-gradient-to-r from-teal-500 to-emerald-500 text-black font-bold" : "text-white"}
                `}
                >
                  {formatDay(day)}
                </span>

                {assignmentsForDay.length > 0 && (
                  <div className="mt-1 w-full">
                    {assignmentsForDay.slice(0, 2).map((assignment, i) => (
                      <div
                        key={assignment.id || i}
                        className={`text-xs truncate px-1 py-0.5 mt-0.5 rounded ${getAssignmentColor(assignment.size)}`}
                        title={assignment.title}
                      >
                        {assignment.title.length > 10 ? assignment.title.substring(0, 10) + "..." : assignment.title}
                      </div>
                    ))}
                    {assignmentsForDay.length > 2 && (
                      <div className="text-xs text-center text-teal-500 mt-0.5">
                        +{assignmentsForDay.length - 2} more
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>
          )
        })}
      </div>

      {/* Debug panel */}
      {debugMode && (
        <div className="mt-6 bg-gray-800 border border-gray-700 rounded-lg p-4 text-xs">
          <h3 className="font-medium text-white mb-2">Calendar Debug Info:</h3>
          <div className="text-gray-300">
            <p>Current Date: {currentDate.toISOString()}</p>
            <p>Total Assignments: {assignments?.length || 0}</p>
            <div className="mt-2">
              <p className="font-medium">Assignments:</p>
              <ul className="mt-1 space-y-1">
                {assignments?.slice(0, 5).map((assignment, i) => (
                  <li key={i} className="text-gray-400">
                    "{assignment.title}" - Due: {new Date(assignment.deadline).toLocaleDateString()} ({assignment.size})
                  </li>
                ))}
                {assignments?.length > 5 && <li className="text-gray-500">...and {assignments.length - 5} more</li>}
              </ul>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
