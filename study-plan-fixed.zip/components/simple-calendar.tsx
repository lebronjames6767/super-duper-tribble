"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { ChevronLeft, ChevronRight } from "lucide-react"
import { cn } from "@/lib/utils"

interface Assignment {
  id: number
  title: string
  subject: string
  dueDate: Date
  priority: "low" | "medium" | "high"
  status: "not-started" | "in-progress" | "completed" | "overdue"
  progress: number
}

interface SimpleCalendarProps {
  assignments: Assignment[]
}

export function SimpleCalendar({ assignments }: SimpleCalendarProps) {
  const [currentDate, setCurrentDate] = useState(new Date())

  const today = new Date()
  const year = currentDate.getFullYear()
  const month = currentDate.getMonth()

  // Get first day of month and number of days
  const firstDayOfMonth = new Date(year, month, 1)
  const lastDayOfMonth = new Date(year, month + 1, 0)
  const firstDayWeekday = firstDayOfMonth.getDay()
  const daysInMonth = lastDayOfMonth.getDate()

  // Generate calendar days
  const calendarDays = []

  // Add empty cells for days before month starts
  for (let i = 0; i < firstDayWeekday; i++) {
    calendarDays.push(null)
  }

  // Add days of the month
  for (let day = 1; day <= daysInMonth; day++) {
    calendarDays.push(day)
  }

  const navigateMonth = (direction: "prev" | "next") => {
    setCurrentDate((prev) => {
      const newDate = new Date(prev)
      if (direction === "prev") {
        newDate.setMonth(prev.getMonth() - 1)
      } else {
        newDate.setMonth(prev.getMonth() + 1)
      }
      return newDate
    })
  }

  const getAssignmentsForDate = (day: number) => {
    const date = new Date(year, month, day)
    return assignments.filter((assignment) => {
      const assignmentDate = new Date(assignment.dueDate)
      return assignmentDate.toDateString() === date.toDateString()
    })
  }

  const isToday = (day: number) => {
    const date = new Date(year, month, day)
    return date.toDateString() === today.toDateString()
  }

  const isPastDate = (day: number) => {
    const date = new Date(year, month, day)
    return date < today && !isToday(day)
  }

  const monthNames = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December",
  ]

  const dayNames = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"]

  return (
    <div className="space-y-4">
      {/* Calendar Header */}
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold">
          {monthNames[month]} {year}
        </h3>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={() => navigateMonth("prev")} className="h-8 w-8 p-0">
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <Button variant="outline" size="sm" onClick={() => navigateMonth("next")} className="h-8 w-8 p-0">
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* Calendar Grid */}
      <div className="grid grid-cols-7 gap-1">
        {/* Day headers */}
        {dayNames.map((day) => (
          <div key={day} className="p-2 text-center text-sm font-medium text-muted-foreground">
            {day}
          </div>
        ))}

        {/* Calendar days */}
        {calendarDays.map((day, index) => {
          if (day === null) {
            return <div key={index} className="p-2 h-20" />
          }

          const dayAssignments = getAssignmentsForDate(day)
          const hasOverdue = dayAssignments.some((a) => a.status === "overdue")
          const hasHigh = dayAssignments.some((a) => a.priority === "high")

          return (
            <div
              key={day}
              className={cn(
                "p-1 h-20 border border-border/50 rounded-lg relative overflow-hidden",
                isToday(day) && "bg-emerald-50 dark:bg-emerald-950 border-emerald-200 dark:border-emerald-800",
                isPastDate(day) && "bg-muted/30",
                dayAssignments.length > 0 && "bg-blue-50/50 dark:bg-blue-950/20",
              )}
            >
              <div
                className={cn(
                  "text-sm font-medium mb-1",
                  isToday(day) && "text-emerald-700 dark:text-emerald-300",
                  isPastDate(day) && "text-muted-foreground",
                )}
              >
                {day}
              </div>

              {/* Assignment indicators */}
              <div className="space-y-1">
                {dayAssignments.slice(0, 2).map((assignment, idx) => (
                  <div
                    key={idx}
                    className={cn(
                      "text-xs px-1 py-0.5 rounded truncate",
                      assignment.status === "overdue" && "bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-300",
                      assignment.status === "completed" &&
                        "bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300",
                      assignment.status === "in-progress" &&
                        "bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300",
                      assignment.status === "not-started" &&
                        assignment.priority === "high" &&
                        "bg-orange-100 text-orange-700 dark:bg-orange-900/30 dark:text-orange-300",
                      assignment.status === "not-started" &&
                        assignment.priority !== "high" &&
                        "bg-gray-100 text-gray-700 dark:bg-gray-800 dark:text-gray-300",
                    )}
                    title={`${assignment.title} - ${assignment.subject}`}
                  >
                    {assignment.title.length > 8 ? assignment.title.substring(0, 8) + "..." : assignment.title}
                  </div>
                ))}

                {dayAssignments.length > 2 && (
                  <div className="text-xs text-muted-foreground px-1">+{dayAssignments.length - 2} more</div>
                )}
              </div>

              {/* Priority/Status indicators */}
              {hasOverdue && <div className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full" />}
              {!hasOverdue && hasHigh && <div className="absolute top-1 right-1 w-2 h-2 bg-orange-500 rounded-full" />}
            </div>
          )
        })}
      </div>

      {/* Legend */}
      <div className="flex flex-wrap gap-4 text-xs text-muted-foreground">
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 bg-red-500 rounded-full" />
          <span>Overdue</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 bg-orange-500 rounded-full" />
          <span>High Priority</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 bg-emerald-500 rounded-full" />
          <span>Completed</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 bg-blue-500 rounded-full" />
          <span>In Progress</span>
        </div>
      </div>
    </div>
  )
}
