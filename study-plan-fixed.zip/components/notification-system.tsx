"use client"

import { useState, useEffect } from "react"
import { Bell, Calendar, Clock, CheckCircle, AlertTriangle, Info, ThumbsUp, Award, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useNotifications, type Notification } from "@/context/notification-context"

export function NotificationSystem() {
  const [currentNotification, setCurrentNotification] = useState<Notification | null>(null)
  const [showNotification, setShowNotification] = useState(false)
  const [notificationQueue, setNotificationQueue] = useState<Notification[]>([])
  const { notifications, markAsRead, dismissNotification } = useNotifications()

  // Process notification queue
  useEffect(() => {
    try {
      // Filter unread, undismissed notifications and sort by priority
      const unreadNotifications = notifications
        .filter((n) => !n.read && !n.dismissed)
        .sort((a, b) => {
          const priorityValues = { high: 3, medium: 2, low: 1 }
          return priorityValues[b.priority] - priorityValues[a.priority]
        })

      // Update the queue with new unread notifications
      setNotificationQueue(unreadNotifications)
    } catch (error) {
      console.error("Error processing notifications:", error)
    }
  }, [notifications])

  // Process notification queue
  useEffect(() => {
    try {
      // If we're not showing a notification and there are notifications in the queue
      if (!showNotification && notificationQueue.length > 0) {
        // Get the next notification from the queue
        const nextNotification = notificationQueue[0]

        // Remove it from the queue
        setNotificationQueue((prevQueue) => prevQueue.slice(1))

        // Show the notification
        setCurrentNotification(nextNotification)
        setShowNotification(true)

        // Mark as read
        markAsRead(nextNotification.id)
      }
    } catch (error) {
      console.error("Error showing notification:", error)
    }
  }, [showNotification, notificationQueue, markAsRead])

  // Auto-hide notification after 8 seconds
  useEffect(() => {
    let timer: NodeJS.Timeout

    if (showNotification) {
      timer = setTimeout(() => {
        handleDismiss()
      }, 8000)
    }

    return () => {
      if (timer) clearTimeout(timer)
    }
  }, [showNotification])

  const handleDismiss = () => {
    setShowNotification(false)

    // Mark current notification as dismissed
    if (currentNotification) {
      dismissNotification(currentNotification.id)

      // Clear current notification after animation completes
      setTimeout(() => {
        setCurrentNotification(null)
      }, 300)
    }
  }

  const handleAction = () => {
    if (currentNotification?.actionUrl) {
      // Navigate to the action URL
      window.location.href = currentNotification.actionUrl
    }

    // Dismiss the notification
    handleDismiss()
  }

  // Get icon based on notification type
  const getNotificationIcon = (type: string) => {
    switch (type) {
      case "deadline":
        return <Calendar className="h-5 w-5" />
      case "reminder":
        return <Clock className="h-5 w-5" />
      case "achievement":
        return <CheckCircle className="h-5 w-5" />
      case "warning":
        return <AlertTriangle className="h-5 w-5" />
      case "info":
        return <Info className="h-5 w-5" />
      case "success":
        return <ThumbsUp className="h-5 w-5" />
      case "milestone":
        return <Award className="h-5 w-5" />
      default:
        return <Bell className="h-5 w-5" />
    }
  }

  if (!showNotification || !currentNotification) {
    return null
  }

  return (
    <div className="fixed top-6 left-1/2 z-50 w-full max-w-md transform -translate-x-1/2">
      <div className="overflow-hidden rounded-xl border shadow-lg bg-gray-900 border-gray-700">
        <div className="relative">
          {/* Colored top bar indicator */}
          <div className="h-1 w-full bg-blue-500" />

          <div className="p-5">
            <div className="flex items-start gap-4">
              <div className="flex-shrink-0 rounded-full p-2.5 bg-blue-500/20 text-blue-400">
                {getNotificationIcon(currentNotification.type)}
              </div>

              <div className="flex-1 min-w-0">
                <h3 className="text-lg font-semibold text-white mb-1 pr-6">{currentNotification.title}</h3>
                <p className="text-gray-300 text-sm leading-relaxed">{currentNotification.message}</p>

                {currentNotification.actionUrl && (
                  <div className="mt-4">
                    <Button size="sm" onClick={handleAction} className="bg-blue-600 hover:bg-blue-700 text-white">
                      {currentNotification.actionText || "View"}
                    </Button>
                  </div>
                )}
              </div>

              <Button
                variant="ghost"
                size="icon"
                className="absolute top-2 right-2 h-8 w-8 rounded-full text-gray-400 hover:bg-gray-800 hover:text-white"
                onClick={handleDismiss}
              >
                <X className="h-4 w-4" />
                <span className="sr-only">Dismiss</span>
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
