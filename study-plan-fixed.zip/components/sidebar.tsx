"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { useAuth } from "@/context/auth-context"
import { usePathname } from "next/navigation"
import Link from "next/link"
import { motion, AnimatePresence } from "framer-motion"
import {
  LayoutDashboard,
  Calendar,
  BookOpen,
  Target,
  Award,
  Settings,
  BarChart3,
  Bell,
  MessageSquare,
  X,
  ChevronRight,
  Sparkles,
  User,
  Menu,
} from "lucide-react"

const navigation = [
  {
    name: "Dashboard",
    href: "/dashboard",
    icon: LayoutDashboard,
  },
  {
    name: "Assignments",
    href: "/dashboard/assignments",
    icon: BookOpen,
  },
  {
    name: "Schedule",
    href: "/dashboard/schedule",
    icon: Calendar,
  },
  {
    name: "Goals",
    href: "/dashboard/goals",
    icon: Target,
  },
  {
    name: "Analytics",
    href: "/dashboard/analytics",
    icon: BarChart3,
  },
  {
    name: "Rewards",
    href: "/dashboard/rewards",
    icon: Award,
  },
  {
    name: "AI Chat",
    href: "/dashboard/chat",
    icon: MessageSquare,
  },
  {
    name: "Notifications",
    href: "/dashboard/notifications",
    icon: Bell,
  },
  {
    name: "Settings",
    href: "/dashboard/settings",
    icon: Settings,
  },
]

export function Sidebar() {
  const { user } = useAuth()
  const pathname = usePathname()
  const [isOpen, setIsOpen] = useState(false)

  useEffect(() => {
    const handleToggle = () => setIsOpen((prev) => !prev)
    document.addEventListener("toggle-sidebar", handleToggle)
    return () => document.removeEventListener("toggle-sidebar", handleToggle)
  }, [])

  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth >= 768) {
        setIsOpen(false)
      }
    }

    window.addEventListener("resize", handleResize)
    return () => window.removeEventListener("resize", handleResize)
  }, [])

  const sidebarContent = (
    <div className="flex h-full flex-col bg-[#0A0118]/95 backdrop-blur-xl">
      {/* Header - Fixed */}
      <div className="flex-shrink-0 p-4 border-b border-emerald-900/20">
        <div className="flex items-center justify-between">
          <motion.div
            className="flex items-center gap-2"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5 }}
          >
            <div className="h-8 w-8 rounded-lg bg-gradient-to-br from-emerald-600 to-emerald-700 flex items-center justify-center shadow-lg">
              <Sparkles className="h-4 w-4 text-white" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-white">Kairos</h2>
              <p className="text-xs text-emerald-300/80">Study Assistant</p>
            </div>
          </motion.div>

          {/* Mobile close button */}
          <Button
            variant="ghost"
            size="icon"
            className="md:hidden h-8 w-8 text-emerald-300 hover:text-white hover:bg-emerald-900/30"
            onClick={() => setIsOpen(false)}
          >
            <X className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* Navigation - Scrollable */}
      <nav className="flex-1 p-3 space-y-1 overflow-y-auto scrollbar-thin scrollbar-thumb-emerald-800 scrollbar-track-transparent">
        {navigation.map((item, index) => {
          const isActive = pathname === item.href
          return (
            <motion.div
              key={item.name}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.3, delay: index * 0.03 }}
            >
              <Link href={item.href} onClick={() => setIsOpen(false)}>
                <motion.div
                  whileHover={{ x: 2, scale: 1.01 }}
                  whileTap={{ scale: 0.98 }}
                  className={`group relative flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all duration-200 ${
                    isActive
                      ? `bg-gradient-to-r from-emerald-600 to-emerald-700 text-white shadow-lg shadow-emerald-900/30`
                      : `text-emerald-200 hover:text-white hover:bg-emerald-900/20 hover:shadow-md`
                  }`}
                >
                  {/* Icon container */}
                  <div
                    className={`flex h-7 w-7 items-center justify-center rounded-md transition-all duration-200 ${
                      isActive
                        ? "bg-white/20 text-white shadow-inner"
                        : `bg-emerald-500/10 text-emerald-300 group-hover:text-white group-hover:bg-white/10`
                    }`}
                  >
                    <item.icon className="h-4 w-4" />
                  </div>

                  {/* Text */}
                  <span className="font-medium text-sm flex-1">{item.name}</span>

                  {/* Active indicator */}
                  {isActive && (
                    <motion.div layoutId="sidebar-indicator" className="flex items-center">
                      <ChevronRight className="h-3 w-3 text-white/80" />
                    </motion.div>
                  )}

                  {/* Hover glow effect */}
                  {!isActive && (
                    <div className="absolute inset-0 rounded-lg bg-gradient-to-r from-transparent via-white/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                  )}
                </motion.div>
              </Link>
            </motion.div>
          )
        })}
      </nav>

      {/* User Profile Section - Fixed */}
      {user && (
        <motion.div
          className="flex-shrink-0 border-t border-emerald-900/20 p-3"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.3 }}
        >
          <div className="flex items-center gap-2 p-2 rounded-lg bg-emerald-900/20 border border-emerald-800/30 hover:bg-emerald-900/30 transition-all duration-200">
            <div className="flex h-8 w-8 items-center justify-center rounded-full bg-gradient-to-br from-emerald-600 to-emerald-700 shadow-lg">
              <User className="h-4 w-4 text-white" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-xs font-medium text-white truncate">{user.email?.split("@")[0] || "Student"}</p>
              <p className="text-xs text-emerald-300/80">Online</p>
            </div>
            <div className="h-2 w-2 bg-emerald-500 rounded-full animate-pulse"></div>
          </div>
        </motion.div>
      )}
    </div>
  )

  return (
    <>
      {/* Mobile overlay */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-40 bg-black/60 backdrop-blur-sm md:hidden"
            onClick={() => setIsOpen(false)}
          />
        )}
      </AnimatePresence>

      {/* Desktop sidebar */}
      <motion.aside
        initial={{ x: -260, opacity: 0 }}
        animate={{ x: 0, opacity: 1 }}
        transition={{ duration: 0.5, ease: "easeOut" }}
        className="hidden md:flex md:w-64 md:flex-col md:fixed md:inset-y-0 md:top-16 z-30"
      >
        <div className="flex flex-col flex-grow h-[calc(100vh-4rem)] border-r border-emerald-900/20 shadow-2xl">
          {sidebarContent}
        </div>
      </motion.aside>

      {/* Mobile sidebar */}
      <AnimatePresence>
        {isOpen && (
          <motion.aside
            initial={{ x: -260 }}
            animate={{ x: 0 }}
            exit={{ x: -260 }}
            transition={{ type: "spring", damping: 25, stiffness: 300 }}
            className="fixed inset-y-0 left-0 z-50 w-64 md:hidden"
          >
            <div className="flex flex-col h-full border-r border-emerald-900/20 shadow-2xl">{sidebarContent}</div>
          </motion.aside>
        )}
      </AnimatePresence>

      {/* Mobile menu button */}
      {!isOpen && (
        <motion.button
          initial={{ scale: 0, rotate: -180 }}
          animate={{ scale: 1, rotate: 0 }}
          transition={{ type: "spring", damping: 20, stiffness: 300 }}
          className="fixed bottom-6 right-6 z-40 flex h-12 w-12 items-center justify-center rounded-full bg-gradient-to-br from-emerald-600 to-emerald-700 text-white shadow-2xl md:hidden hover:shadow-emerald-500/25 transition-all duration-300"
          onClick={() => setIsOpen(true)}
        >
          <Menu className="h-5 w-5" />
        </motion.button>
      )}
    </>
  )
}
