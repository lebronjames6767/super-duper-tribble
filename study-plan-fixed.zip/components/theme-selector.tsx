"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Palette } from "lucide-react"
import { useAuth } from "@/context/auth-context"
import { getBrowserClient } from "@/lib/supabase"
import { useTheme } from "next-themes"

const themes = [
  { name: "light", primary: "#10b981" },
  { name: "dark", primary: "#059669" },
  { name: "system", primary: "#047857" },
]

export function ThemeSelector() {
  const { user } = useAuth()
  const { theme, setTheme } = useTheme()
  const [currentTheme, setCurrentTheme] = useState("dark")
  const [mounted, setMounted] = useState(false)
  const supabase = getBrowserClient()

  useEffect(() => {
    setMounted(true)
  }, [])

  useEffect(() => {
    if (!mounted) return

    setCurrentTheme(theme || "dark")

    const loadTheme = async () => {
      if (!user) return

      try {
        const { data } = await supabase.from("user_preferences").select("theme").eq("user_id", user.id).single()

        if (data?.theme) {
          setCurrentTheme(data.theme)
          setTheme(data.theme)
        }
      } catch (error) {
        console.error("Error loading theme:", error)
      }
    }

    loadTheme()
  }, [user, supabase, setTheme, theme, mounted])

  const saveTheme = async (themeName: string) => {
    if (!user) return

    try {
      const { data } = await supabase.from("user_preferences").select("user_id").eq("user_id", user.id).single()

      if (data) {
        await supabase
          .from("user_preferences")
          .update({ theme: themeName, updated_at: new Date().toISOString() })
          .eq("user_id", user.id)
      } else {
        await supabase.from("user_preferences").insert({
          user_id: user.id,
          theme: themeName,
          study_hours_per_day: 4,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        })
      }
    } catch (error) {
      console.error("Error saving theme:", error)
    }
  }

  const handleThemeChange = (themeName: string) => {
    setCurrentTheme(themeName)
    setTheme(themeName)
    saveTheme(themeName)
  }

  if (!mounted) {
    return (
      <Button variant="outline" size="icon" className="h-8 w-8 border-gray-700 bg-gray-900 text-gray-400" disabled>
        <Palette className="h-4 w-4" />
        <span className="sr-only">Change theme</span>
      </Button>
    )
  }

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button
          variant="outline"
          size="icon"
          className="h-8 w-8 border-gray-700 bg-gray-900 text-gray-400 hover:bg-gray-800 hover:text-white"
        >
          <Palette className="h-4 w-4" />
          <span className="sr-only">Change theme</span>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent className="border-gray-700 bg-gray-800">
        {themes.map((themeOption) => (
          <DropdownMenuItem
            key={themeOption.name}
            className={`flex items-center gap-2 ${currentTheme === themeOption.name ? "bg-gray-700" : ""}`}
            onClick={() => handleThemeChange(themeOption.name)}
          >
            <div className="h-4 w-4 rounded-full" style={{ backgroundColor: themeOption.primary }} />
            <span className="text-white">{themeOption.name}</span>
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  )
}
