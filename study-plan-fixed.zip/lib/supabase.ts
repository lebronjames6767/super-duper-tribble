import { createClient } from "@supabase/supabase-js"
import type { Database } from "@/types/supabase"

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!

// Mock data for development/testing
const mockAssignments = [
  {
    id: "1",
    user_id: "mock-user-1",
    title: "Math Homework Chapter 5",
    description: "Complete exercises 1-20 from algebra textbook",
    deadline: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000).toISOString(),
    subject_id: "math-1",
    size: "Medium",
    completed: false,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  },
  {
    id: "2",
    user_id: "mock-user-1",
    title: "English Essay",
    description: "Write a 5-page essay on Shakespeare's Hamlet",
    deadline: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(),
    subject_id: "english-1",
    size: "Large",
    completed: false,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  },
]

const mockSubjects = [
  {
    id: "math-1",
    user_id: "mock-user-1",
    name: "Mathematics",
    color: "#3B82F6",
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  },
  {
    id: "english-1",
    user_id: "mock-user-1",
    name: "English",
    color: "#8B5CF6",
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  },
  {
    id: "science-1",
    user_id: "mock-user-1",
    name: "Science",
    color: "#10B981",
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  },
  {
    id: "history-1",
    user_id: "mock-user-1",
    name: "History",
    color: "#EF4444",
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  },
]

const mockGoals = [
  {
    id: "goal-1",
    user_id: "mock-user-1",
    title: "Complete Math Homework",
    description: "Finish all math exercises before deadline",
    target_value: 1,
    current_value: 0,
    date: new Date(Date.now() + 2 * 24 * 60 * 60 * 1000).toISOString().split("T")[0],
    completed: false,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  },
]

const mockUserPoints = [
  {
    id: "points-1",
    user_id: "mock-user-1",
    points: 150,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  },
]

const mockRewards = [
  {
    id: "reward-1",
    name: "15-Minute Break",
    description: "Take a relaxing 15-minute break from studying (Duration: 15 minutes)",
    cost: 25,
    created_at: new Date().toISOString(),
  },
  {
    id: "reward-2",
    name: "30-Minute Art Time",
    description: "Spend 30 minutes drawing or doing creative activities (Duration: 30 minutes)",
    cost: 50,
    created_at: new Date().toISOString(),
  },
  {
    id: "reward-3",
    name: "Spin the Wheel",
    description: "Spin the wheel for a chance to win special rewards!",
    cost: 75,
    created_at: new Date().toISOString(),
  },
]

const mockUserRewards = []

const mockNotifications = []

// Mock query builder classes
class MockQueryBuilder {
  private data: any[]
  private filters: Array<{ column: string; value: any; operator: string }> = []
  private orderBy: { column: string; ascending: boolean } | null = null
  private limitValue: number | null = null
  private selectColumns = "*"

  constructor(data: any[]) {
    this.data = [...data]
  }

  select(columns = "*") {
    this.selectColumns = columns
    return this
  }

  eq(column: string, value: any) {
    this.filters.push({ column, value, operator: "eq" })
    return this
  }

  order(column: string, options: { ascending?: boolean } = {}) {
    this.orderBy = { column, ascending: options.ascending !== false }
    return this
  }

  limit(count: number) {
    this.limitValue = count
    return this
  }

  async single() {
    const result = await this.execute()
    if (result.data && result.data.length > 0) {
      return { data: result.data[0], error: null }
    }
    return { data: null, error: { code: "PGRST116", message: "No rows found" } }
  }

  async execute() {
    let filteredData = [...this.data]

    // Apply filters
    for (const filter of this.filters) {
      filteredData = filteredData.filter((item) => {
        if (filter.operator === "eq") {
          return item[filter.column] === filter.value
        }
        return true
      })
    }

    // Apply ordering
    if (this.orderBy) {
      filteredData.sort((a, b) => {
        const aVal = a[this.orderBy!.column]
        const bVal = b[this.orderBy!.column]

        if (aVal < bVal) return this.orderBy!.ascending ? -1 : 1
        if (aVal > bVal) return this.orderBy!.ascending ? 1 : -1
        return 0
      })
    }

    // Apply limit
    if (this.limitValue) {
      filteredData = filteredData.slice(0, this.limitValue)
    }

    return { data: filteredData, error: null }
  }

  // Make the builder thenable so it can be awaited directly
  then(onFulfilled?: any, onRejected?: any) {
    return this.execute().then(onFulfilled, onRejected)
  }
}

class MockInsertBuilder {
  private tableName: string
  private insertData: any

  constructor(tableName: string, data: any) {
    this.tableName = tableName
    this.insertData = data
  }

  select(columns = "*") {
    return this
  }

  single() {
    return this
  }

  async then(onFulfilled?: any, onRejected?: any) {
    // Generate a mock ID
    const mockId = `${this.tableName}-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`

    const newRecord = {
      id: mockId,
      ...this.insertData,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    }

    // Add to appropriate mock data array
    switch (this.tableName) {
      case "assignments":
        mockAssignments.push(newRecord)
        break
      case "subjects":
        mockSubjects.push(newRecord)
        break
      case "goals":
        mockGoals.push(newRecord)
        break
      case "user_points":
        mockUserPoints.push(newRecord)
        break
      case "user_rewards":
        mockUserRewards.push(newRecord)
        break
      case "notifications":
        mockNotifications.push(newRecord)
        break
    }

    const result = { data: newRecord, error: null }
    return onFulfilled ? onFulfilled(result) : result
  }
}

class MockUpdateBuilder {
  private tableName: string
  private updateData: any
  private filters: Array<{ column: string; value: any; operator: string }> = []

  constructor(tableName: string, data: any) {
    this.tableName = tableName
    this.updateData = data
  }

  eq(column: string, value: any) {
    this.filters.push({ column, value, operator: "eq" })
    return this
  }

  select(columns = "*") {
    return this
  }

  single() {
    return this
  }

  async then(onFulfilled?: any, onRejected?: any) {
    let dataArray: any[] = []

    // Get the appropriate data array
    switch (this.tableName) {
      case "assignments":
        dataArray = mockAssignments
        break
      case "subjects":
        dataArray = mockSubjects
        break
      case "goals":
        dataArray = mockGoals
        break
      case "user_points":
        dataArray = mockUserPoints
        break
      case "user_rewards":
        dataArray = mockUserRewards
        break
      case "notifications":
        dataArray = mockNotifications
        break
    }

    // Find and update matching records
    const updatedRecords = []
    for (let i = 0; i < dataArray.length; i++) {
      const item = dataArray[i]
      let matches = true

      for (const filter of this.filters) {
        if (filter.operator === "eq" && item[filter.column] !== filter.value) {
          matches = false
          break
        }
      }

      if (matches) {
        const updatedItem = {
          ...item,
          ...this.updateData,
          updated_at: new Date().toISOString(),
        }
        dataArray[i] = updatedItem
        updatedRecords.push(updatedItem)
      }
    }

    const result = {
      data: updatedRecords.length > 0 ? updatedRecords : null,
      error: null,
    }
    return onFulfilled ? onFulfilled(result) : result
  }
}

// Mock Supabase client
const mockSupabaseClient = {
  from: (table: string) => {
    const getTableData = () => {
      switch (table) {
        case "assignments":
          return mockAssignments
        case "subjects":
          return mockSubjects
        case "goals":
          return mockGoals
        case "user_points":
          return mockUserPoints
        case "rewards":
          return mockRewards
        case "user_rewards":
          return mockUserRewards
        case "notifications":
          return mockNotifications
        default:
          return []
      }
    }

    return {
      select: (columns = "*") => new MockQueryBuilder(getTableData()).select(columns),
      insert: (data: any) => new MockInsertBuilder(table, data),
      update: (data: any) => new MockUpdateBuilder(table, data),
      delete: () => ({
        eq: (column: string, value: any) => ({
          then: async (onFulfilled?: any) => {
            const dataArray = getTableData()
            const initialLength = dataArray.length

            // Remove matching items
            for (let i = dataArray.length - 1; i >= 0; i--) {
              if (dataArray[i][column] === value) {
                dataArray.splice(i, 1)
              }
            }

            const result = {
              data: null,
              error: dataArray.length < initialLength ? null : { message: "No matching records found" },
            }
            return onFulfilled ? onFulfilled(result) : result
          },
        }),
      }),
    }
  },
  auth: {
    getUser: async () => ({
      data: {
        user: {
          id: "mock-user-1",
          email: "test@example.com",
          user_metadata: { name: "Test User" },
        },
      },
      error: null,
    }),
    signInWithPassword: async () => ({
      data: { user: { id: "mock-user-1" }, session: { access_token: "mock-token" } },
      error: null,
    }),
    signUp: async () => ({
      data: { user: { id: "mock-user-1" }, session: { access_token: "mock-token" } },
      error: null,
    }),
    signOut: async () => ({ error: null }),
    onAuthStateChange: () => ({
      data: { subscription: { unsubscribe: () => {} } },
    }),
  },
}

// Check if we're in a browser environment and have the required environment variables
const isClient = typeof window !== "undefined"
const hasSupabaseConfig = supabaseUrl && supabaseAnonKey && supabaseUrl !== "your-supabase-url"

export function getBrowserClient() {
  if (!isClient || !hasSupabaseConfig) {
    console.log("Using mock Supabase client")
    return mockSupabaseClient as any
  }

  return createClient<Database>(supabaseUrl, supabaseAnonKey)
}

export function getServerClient() {
  if (!hasSupabaseConfig) {
    console.log("Using mock Supabase client on server")
    return mockSupabaseClient as any
  }

  return createClient<Database>(supabaseUrl, supabaseAnonKey)
}
