// Theme definitions
export interface Theme {
  name: string
  primary: string
  accent: string
}

export const themes: Theme[] = [
  { name: "Default", primary: "#10b981", accent: "#059669" }, // Emerald green
  { name: "Ocean", primary: "#0ea5e9", accent: "#2563eb" },
  { name: "Sunset", primary: "#f97316", accent: "#db2777" },
  { name: "Forest", primary: "#22c55e", accent: "#15803d" },
  { name: "Berry", primary: "#d946ef", accent: "#9333ea" },
  { name: "Midnight", primary: "#3b82f6", accent: "#1e3a8a" },
  { name: "Amber", primary: "#f59e0b", accent: "#b45309" },
  { name: "Rose", primary: "#f43f5e", accent: "#be123c" },
]

// Apply theme to document
export function applyTheme(themeName: string): void {
  if (typeof window === "undefined") return

  const theme = themes.find((t) => t.name === themeName) || themes[0]

  // Update CSS variables with !important to ensure they don't get overridden
  document.documentElement.style.setProperty("--primary", theme.primary, "important")
  document.documentElement.style.setProperty("--accent", theme.accent, "important")

  // Also update the HSL values for Tailwind
  if (theme.name === "Default") {
    document.documentElement.style.setProperty("--primary-hsl", "160 84% 39%", "important")
    document.documentElement.style.setProperty("--accent-hsl", "160 84% 35%", "important")
  } else if (theme.name === "Ocean") {
    document.documentElement.style.setProperty("--primary-hsl", "199 89% 48%", "important")
    document.documentElement.style.setProperty("--accent-hsl", "221 83% 53%", "important")
  }

  // Set data attribute for theme
  document.documentElement.setAttribute("data-theme", themeName.toLowerCase())

  // Apply theme class to body
  document.body.className = document.body.className.replace(/theme-\w+/g, "").trim()
  document.body.classList.add(`theme-${themeName.toLowerCase()}`)

  // Store in localStorage for persistence
  localStorage.setItem("current-theme", themeName)

  // Force update of CSS custom properties by triggering a reflow
  const reflow = document.body.offsetHeight
}

// Get current theme from localStorage
export function getCurrentTheme(): string {
  if (typeof window === "undefined") return "Default"
  return localStorage.getItem("current-theme") || "Default"
}

// Apply theme on page load
export function initializeTheme(): void {
  if (typeof window === "undefined") return

  // Get theme from localStorage
  const savedTheme = getCurrentTheme()

  // Apply theme immediately
  applyTheme(savedTheme)

  // Set up a recurring check to ensure theme persistence
  const ensureTheme = () => {
    const currentTheme = getCurrentTheme()
    const dataTheme = document.documentElement.getAttribute("data-theme")

    if (!dataTheme || dataTheme !== currentTheme.toLowerCase()) {
      applyTheme(currentTheme)
    }
  }

  // Check theme every second
  const themeInterval = setInterval(ensureTheme, 1000)

  // Clean up interval on page unload
  window.addEventListener("beforeunload", () => {
    clearInterval(themeInterval)
  })

  // Set up a MutationObserver as backup
  const observer = new MutationObserver((mutations) => {
    ensureTheme()
  })

  // Start observing the document
  observer.observe(document.documentElement, {
    attributes: true,
    childList: false,
    subtree: false,
  })
}
