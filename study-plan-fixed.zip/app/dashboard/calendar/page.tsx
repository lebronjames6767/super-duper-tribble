"use client"

import { useState, useEffect, useMemo } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { getBrowserClient } from "@/lib/supabase"
import { useAuth } from "@/context/auth-context"
import type { Database } from "@/types/supabase"
import { ChevronLeft, ChevronRight, CalendarIcon, Clock, CheckCircle2, AlertCircle } from "lucide-react"
import {
  format,
  startOfMonth,
  endOfMonth,
  eachDayOfInterval,
  isSameMonth,
  isSameDay,
  addMonths,
  subMonths,
  isToday,
  parseISO,
  isBefore,
  addDays,
} from "date-fns"
import { motion } from "framer-motion"

type Assignment = Database["public"]["Tables"]["assignments"]["Row"]
type Subject = Database["public"]["Tables"]["subjects"]["Row"]

export default function CalendarPage() {
  const { user } = useAuth()
  const [currentDate, setCurrentDate] = useState(new Date())
  const [assignments, setAssignments] = useState<Assignment[]>([])
  const [subjects, setSubjects] = useState<Subject[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [selectedDay, setSelectedDay] = useState<Date | null>(null)
  const [filter, setFilter] = useState("all") // all, upcoming, completed, overdue
  const supabase = getBrowserClient()

  // Fetch assignments and subjects
  useEffect(() => {
    const fetchData = async () => {
      if (!user) return

      setIsLoading(true)

      try {
        // Fetch assignments
        const { data: assignmentsData, error: assignmentsError } = await supabase
          .from("assignments")
          .select("*")
          .eq("user_id", user.id)
          .order("deadline", { ascending: true })

        if (assignmentsError) {
          console.error("Error fetching assignments:", assignmentsError)
        } else {
          setAssignments(assignmentsData || [])
        }

        // Fetch subjects
        const { data: subjectsData, error: subjectsError } = await supabase
          .from("subjects")
          .select("*")
          .eq("user_id", user.id)

        if (subjectsError) {
          console.error("Error fetching subjects:", subjectsError)
        } else {
          setSubjects(subjectsData || [])
        }
      } catch (error) {
        console.error("Error fetching data:", error)
      } finally {
        setIsLoading(false)
      }
    }

    fetchData()
  }, [user, supabase])

  // Generate calendar days
  const calendarDays = useMemo(() => {
    const monthStart = startOfMonth(currentDate)
    const monthEnd = endOfMonth(currentDate)
    const daysInMonth = eachDayOfInterval({ start: monthStart, end: monthEnd })

    // Get the day of the week of the first day (0 = Sunday, 1 = Monday, etc.)
    const startDay = monthStart.getDay()

    // Add empty days at the beginning to align with the correct day of week
    const emptyDaysBefore = Array(startDay).fill(null)

    // Calculate how many empty days we need at the end to make complete weeks
    const totalDaysShown = emptyDaysBefore.length + daysInMonth.length
    const remainingCells = totalDaysShown % 7 === 0 ? 0 : 7 - (totalDaysShown % 7)
    const emptyDaysAfter = Array(remainingCells).fill(null)

    return [...emptyDaysBefore, ...daysInMonth, ...emptyDaysAfter]
  }, [currentDate])

  // Get assignments for a specific day
  const getAssignmentsForDay = (day: Date | null) => {
    if (!day || !assignments) return []

    return assignments.filter((assignment) => {
      try {
        if (!assignment.deadline) return false
        const deadlineDate = parseISO(assignment.deadline)
        return isSameDay(deadlineDate, day)
      } catch (error) {
        console.error("Error checking assignment date:", error)
        return false
      }
    })
  }

  // Get subject name and color
  const getSubjectInfo = (subjectId: string | null) => {
    if (!subjectId) {
      return { name: "Uncategorized", color: "#6B7280" }
    }

    const subject = subjects.find((s) => s.id === subjectId)
    return {
      name: subject ? subject.name : "Uncategorized",
      color: subject ? subject.color : "#6B7280",
    }
  }

  // Get assignments for the selected day
  const selectedDayAssignments = useMemo(() => {
    return getAssignmentsForDay(selectedDay)
  }, [selectedDay, assignments])

  // Navigate to previous/next month
  const navigateMonth = (direction: "prev" | "next") => {
    setCurrentDate((prev) => (direction === "prev" ? subMonths(prev, 1) : addMonths(prev, 1)))
    setSelectedDay(null)
  }

  // Get status of an assignment
  const getAssignmentStatus = (assignment: Assignment) => {
    if (assignment.completed) return "completed"

    const deadlineDate = parseISO(assignment.deadline)
    const today = new Date()

    if (isBefore(deadlineDate, today)) return "overdue"
    if (isBefore(deadlineDate, addDays(today, 3))) return "upcoming"

    return "scheduled"
  }

  // Filter assignments based on status
  const filteredAssignments = useMemo(() => {
    if (filter === "all") return assignments

    return assignments.filter((assignment) => {
      const status = getAssignmentStatus(assignment)

      if (filter === "completed" && status === "completed") return true
      if (filter === "overdue" && status === "overdue") return true
      if (filter === "upcoming" && (status === "upcoming" || status === "scheduled")) return true

      return false
    })
  }, [assignments, filter])

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-white">Assignment Calendar</h1>
        <p className="text-gray-400">View and manage your assignments by date</p>
      </div>

      <div className="flex flex-col md:flex-row justify-between gap-4 items-center">
        <div className="flex items-center gap-2">
          <Button
            onClick={() => navigateMonth("prev")}
            variant="outline"
            size="icon"
            className="h-9 w-9 rounded-full border-gray-700 bg-gray-900 text-white hover:bg-gray-800"
          >
            <ChevronLeft className="h-5 w-5" />
            <span className="sr-only">Previous month</span>
          </Button>
          <h2 className="text-xl font-bold text-white px-2">{format(currentDate, "MMMM yyyy")}</h2>
          <Button
            onClick={() => navigateMonth("next")}
            variant="outline"
            size="icon"
            className="h-9 w-9 rounded-full border-gray-700 bg-gray-900 text-white hover:bg-gray-800"
          >
            <ChevronRight className="h-5 w-5" />
            <span className="sr-only">Next month</span>
          </Button>
          <Button
            onClick={() => {
              setCurrentDate(new Date())
              setSelectedDay(new Date())
            }}
            variant="outline"
            className="ml-2 border-gray-700 bg-gray-900 text-white hover:bg-gray-800"
          >
            Today
          </Button>
        </div>

        <Tabs defaultValue="all" value={filter} onValueChange={setFilter} className="w-full md:w-auto">
          <TabsList className="bg-gray-900 w-full md:w-auto">
            <TabsTrigger value="all" className="data-[state=active]:bg-gray-800">
              All
            </TabsTrigger>
            <TabsTrigger value="upcoming" className="data-[state=active]:bg-gray-800">
              Upcoming
            </TabsTrigger>
            <TabsTrigger value="completed" className="data-[state=active]:bg-gray-800">
              Completed
            </TabsTrigger>
            <TabsTrigger value="overdue" className="data-[state=active]:bg-gray-800">
              Overdue
            </TabsTrigger>
          </TabsList>
        </Tabs>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-7 gap-4">
        {/* Calendar - Desktop View */}
        <Card className="col-span-1 md:col-span-7 border-gray-700 bg-gray-900 overflow-hidden">
          <CardContent className="p-0">
            {/* Day headers */}
            <div className="grid grid-cols-7 bg-gray-800">
              {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((day) => (
                <div key={day} className="text-center py-3 text-gray-400 font-medium">
                  {day}
                </div>
              ))}
            </div>

            {/* Calendar grid */}
            <div className="grid grid-cols-7 auto-rows-fr border-t border-gray-700">
              {calendarDays.map((day, index) => {
                if (!day) {
                  // Empty day
                  return <div key={`empty-${index}`} className="border-b border-r border-gray-700 bg-gray-900/50 p-1" />
                }

                const isCurrentMonth = isSameMonth(day, currentDate)
                const isCurrentDay = isToday(day)
                const isSelected = selectedDay ? isSameDay(day, selectedDay) : false
                const dayAssignments = getAssignmentsForDay(day)
                const hasAssignments = dayAssignments.length > 0

                return (
                  <div
                    key={day.toString()}
                    className={`border-b border-r border-gray-700 p-1 min-h-[100px] transition-colors
                      ${!isCurrentMonth ? "bg-gray-900/30 opacity-50" : ""}
                      ${isSelected ? "bg-gray-800" : ""}
                      ${isCurrentDay && !isSelected ? "bg-gray-800/50" : ""}
                      hover:bg-gray-800/70 cursor-pointer
                    `}
                    onClick={() => setSelectedDay(day)}
                  >
                    <div className="h-full flex flex-col">
                      <div className="flex justify-between items-center mb-1">
                        <span
                          className={`
                            flex items-center justify-center w-7 h-7 rounded-full text-sm font-medium
                            ${isCurrentDay ? "bg-[#08efb5] text-black" : "text-white"}
                            ${isSelected && !isCurrentDay ? "bg-purple-500 text-white" : ""}
                          `}
                        >
                          {format(day, "d")}
                        </span>
                        {hasAssignments && (
                          <Badge className="bg-[#08efb5]/20 text-[#08efb5] text-xs">{dayAssignments.length}</Badge>
                        )}
                      </div>

                      <div className="flex-1 overflow-hidden">
                        {dayAssignments.slice(0, 2).map((assignment) => {
                          const subjectInfo = getSubjectInfo(assignment.subject_id)
                          const status = getAssignmentStatus(assignment)

                          return (
                            <div
                              key={assignment.id}
                              className={`
                                text-xs mb-1 p-1 rounded truncate flex items-center gap-1
                                ${
                                  status === "completed"
                                    ? "bg-green-900/30 text-green-400"
                                    : status === "overdue"
                                      ? "bg-red-900/30 text-red-400"
                                      : status === "upcoming"
                                        ? "bg-amber-900/30 text-amber-400"
                                        : "bg-gray-800 text-white"
                                }
                              `}
                              style={{ borderLeft: `3px solid ${subjectInfo.color}` }}
                            >
                              {status === "completed" ? (
                                <CheckCircle2 className="h-3 w-3 flex-shrink-0" />
                              ) : status === "overdue" ? (
                                <AlertCircle className="h-3 w-3 flex-shrink-0" />
                              ) : (
                                <Clock className="h-3 w-3 flex-shrink-0" />
                              )}
                              <span className="truncate">{assignment.title}</span>
                            </div>
                          )
                        })}
                        {dayAssignments.length > 2 && (
                          <div className="text-xs text-[#08efb5] mt-1">+{dayAssignments.length - 2} more</div>
                        )}
                      </div>
                    </div>
                  </div>
                )
              })}
            </div>
          </CardContent>
        </Card>

        {/* Selected day details */}
        {selectedDay && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="col-span-1 md:col-span-7"
          >
            <Card className="border-gray-700 bg-gray-900">
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-bold text-white">
                    Assignments for {format(selectedDay, "EEEE, MMMM d, yyyy")}
                  </h3>
                  <Button
                    variant="outline"
                    size="sm"
                    className="border-gray-700 bg-gray-800 text-white hover:bg-gray-700"
                    onClick={() => setSelectedDay(null)}
                  >
                    Close
                  </Button>
                </div>

                {selectedDayAssignments.length === 0 ? (
                  <div className="text-center py-8">
                    <CalendarIcon className="mx-auto h-12 w-12 text-gray-600" />
                    <h3 className="mt-2 text-sm font-medium text-gray-400">No assignments</h3>
                    <p className="mt-1 text-sm text-gray-500">No assignments due on this day.</p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {selectedDayAssignments.map((assignment) => {
                      const subjectInfo = getSubjectInfo(assignment.subject_id)
                      const status = getAssignmentStatus(assignment)

                      return (
                        <div
                          key={assignment.id}
                          className="flex items-center justify-between p-3 rounded-lg border border-gray-700 bg-gray-800"
                        >
                          <div className="flex items-center gap-3">
                            <div className="w-3 h-10 rounded-full" style={{ backgroundColor: subjectInfo.color }}></div>
                            <div>
                              <h4 className="font-medium text-white">{assignment.title}</h4>
                              <div className="flex items-center gap-2 mt-1">
                                <Badge variant="outline" className="text-xs border-gray-600 text-gray-400">
                                  {subjectInfo.name}
                                </Badge>
                                <Badge
                                  className={`text-xs ${
                                    status === "completed"
                                      ? "bg-green-900/30 text-green-400"
                                      : status === "overdue"
                                        ? "bg-red-900/30 text-red-400"
                                        : status === "upcoming"
                                          ? "bg-amber-900/30 text-amber-400"
                                          : "bg-gray-700 text-white"
                                  }`}
                                >
                                  {status.charAt(0).toUpperCase() + status.slice(1)}
                                </Badge>
                                <span className="text-xs text-gray-500">
                                  {assignment.size.charAt(0).toUpperCase() + assignment.size.slice(1)} Assignment
                                </span>
                              </div>
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            <Button
                              variant="outline"
                              size="sm"
                              className={`
                                ${
                                  assignment.completed
                                    ? "border-green-500 bg-green-500/10 text-green-500 hover:bg-green-500/20"
                                    : "border-amber-500 bg-amber-500/10 text-amber-500 hover:bg-amber-500/20"
                                }
                              `}
                            >
                              {assignment.completed ? (
                                <>
                                  <CheckCircle2 className="mr-1 h-4 w-4" />
                                  Completed
                                </>
                              ) : (
                                <>
                                  <Clock className="mr-1 h-4 w-4" />
                                  Mark Complete
                                </>
                              )}
                            </Button>
                          </div>
                        </div>
                      )
                    })}
                  </div>
                )}
              </CardContent>
            </Card>
          </motion.div>
        )}
      </div>
    </div>
  )
}
