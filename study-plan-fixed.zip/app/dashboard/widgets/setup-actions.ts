"use server"

import { createServerClient } from "@/lib/supabase"
import { cookies } from "next/headers"
import { revalidatePath } from "next/cache"

export async function checkWidgetTablesExist() {
  const cookieStore = cookies()
  const supabase = createServerClient(cookieStore)

  try {
    // Try to query the widgets table
    const { data, error } = await supabase.from("widgets").select("id").limit(1)

    // If there's no error, the table exists
    return !error
  } catch (error) {
    console.error("Error checking if widget tables exist:", error)
    return false
  }
}

export async function createWidgetTables() {
  const cookieStore = cookies()
  const supabase = createServerClient(cookieStore)

  try {
    // Create widgets table
    await supabase.rpc("create_widget_tables")

    // Revalidate the page to show the new UI
    revalidatePath("/dashboard/widgets")
    return true
  } catch (error) {
    console.error("Error creating widget tables:", error)
    return false
  }
}
