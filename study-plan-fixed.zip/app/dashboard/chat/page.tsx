"use client"

import type React from "react"
import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { useToast } from "@/hooks/use-toast"
import { useAuth } from "@/context/auth-context"
import { getBrowserClient } from "@/lib/supabase"
import { useNotifications } from "@/context/notification-context"
import { addPoints } from "@/lib/local-storage"
import { Loader2, Upload, Send } from "lucide-react"
import Link from "next/link"

interface Message {
  id: string
  content: string
  sender: "user" | "ai"
  timestamp: Date
}

interface FileUpload {
  file: File
  content?: string
  metadata?: any
}

export default function ChatPage() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      content:
        "Hello! I'm here to help you break down your assignments into manageable daily tasks. What assignment would you like help with today?",
      sender: "ai",
      timestamp: new Date(),
    },
  ])
  const [inputMessage, setInputMessage] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [uploadedFile, setUploadedFile] = useState<File | null>(null)
  const [pdfContent, setPdfContent] = useState<string>("")
  const [error, setError] = useState("")
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const { toast } = useToast()
  const { user } = useAuth()
  const { notifyAssignmentCreated, notifyPointsEarned } = useNotifications()
  const supabase = getBrowserClient()

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const addToSchedule = async (assignmentInfo: any) => {
    if (!user) return

    try {
      // Parse due date to proper format
      let deadline = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString() // Default to 7 days from now

      if (assignmentInfo.dueDate) {
        const dueDate = assignmentInfo.dueDate.toLowerCase()
        const today = new Date()

        if (dueDate.includes("tomorrow")) {
          const tomorrow = new Date(today)
          tomorrow.setDate(today.getDate() + 1)
          deadline = tomorrow.toISOString()
        } else if (dueDate.includes("today")) {
          deadline = today.toISOString()
        } else if (dueDate.includes("next week")) {
          const nextWeek = new Date(today)
          nextWeek.setDate(today.getDate() + 7)
          deadline = nextWeek.toISOString()
        } else {
          // Try to parse the date string
          const parsedDate = new Date(assignmentInfo.dueDate)
          if (!isNaN(parsedDate.getTime())) {
            deadline = parsedDate.toISOString()
          }
        }
      }

      // Extract subject from description
      let subject = "General"
      if (assignmentInfo.description) {
        const desc = assignmentInfo.description.toLowerCase()
        if (desc.includes("math")) subject = "Mathematics"
        else if (desc.includes("english") || desc.includes("writing")) subject = "English"
        else if (desc.includes("science") || desc.includes("chemistry") || desc.includes("physics")) subject = "Science"
        else if (desc.includes("history")) subject = "History"
      }

      // First, check if subject exists, if not create it
      const { data: existingSubject } = await supabase
        .from("subjects")
        .select("id")
        .eq("name", subject)
        .eq("user_id", user.id)
        .single()

      let subjectId = existingSubject?.id

      if (!subjectId) {
        // Create new subject
        const subjectColors = {
          Mathematics: "#3B82F6",
          English: "#8B5CF6",
          Science: "#10B981",
          History: "#EF4444",
          General: "#6B7280",
        }

        const { data: newSubject } = await supabase
          .from("subjects")
          .insert({
            name: subject,
            color: subjectColors[subject] || "#6B7280",
            user_id: user.id,
          })
          .select("id")
          .single()

        subjectId = newSubject?.id
      }

      // Determine assignment size based on description and deadline
      let size = "Medium"
      const daysUntilDeadline = Math.ceil((new Date(deadline).getTime() - Date.now()) / (1000 * 60 * 60 * 24))

      if (assignmentInfo.description) {
        const desc = assignmentInfo.description.toLowerCase()
        if (desc.includes("essay") || desc.includes("project") || desc.includes("research")) {
          size = "Large"
        } else if (desc.includes("homework") || desc.includes("worksheet") || desc.includes("quiz")) {
          size = "Small"
        }
      }

      // Adjust size based on time available
      if (daysUntilDeadline <= 1) {
        size = size === "Large" ? "Large" : "Medium"
      } else if (daysUntilDeadline >= 7) {
        size = size === "Small" ? "Small" : "Large"
      }

      // Create the assignment
      const { data: newAssignment, error: assignmentError } = await supabase
        .from("assignments")
        .insert({
          title: assignmentInfo.name || "New Assignment",
          description: assignmentInfo.description || "Assignment breakdown from AI assistant",
          deadline: deadline,
          subject_id: subjectId,
          size: size,
          completed: false,
          user_id: user.id,
        })
        .select()
        .single()

      if (assignmentError) {
        console.error("Error creating assignment:", assignmentError)
        throw assignmentError
      }

      // Award points for creating assignment
      const pointsAwarded = 10
      await addPoints(user.id, pointsAwarded, supabase, toast)

      // Create a goal for completing this assignment
      const goalDeadline = new Date(deadline)
      goalDeadline.setDate(goalDeadline.getDate() - 1) // Set goal deadline 1 day before assignment

      await supabase.from("goals").insert({
        user_id: user.id,
        title: `Complete ${assignmentInfo.name || "Assignment"}`,
        description: `Finish all tasks for ${assignmentInfo.name || "the assignment"} before the deadline`,
        target_value: 1,
        current_value: 0,
        date: goalDeadline.toISOString().split("T")[0],
        completed: false,
      })

      // Send notifications
      notifyAssignmentCreated(assignmentInfo.name || "New Assignment", new Date(deadline))
      notifyPointsEarned(pointsAwarded, "creating an assignment")

      // Create notification for upcoming deadline
      const daysUntilDue = Math.ceil((new Date(deadline).getTime() - Date.now()) / (1000 * 60 * 60 * 24))
      if (daysUntilDue <= 3) {
        // Create urgent deadline notification
        await supabase.from("notifications").insert({
          user_id: user.id,
          title: "Upcoming Deadline",
          message: `${assignmentInfo.name || "Assignment"} is due in ${daysUntilDue} day${daysUntilDue !== 1 ? "s" : ""}!`,
          type: "deadline",
          read: false,
          dismissed: false,
          action_url: "/dashboard/assignments",
          action_text: "View Assignment",
        })
      }

      toast({
        title: "Added to Schedule! 📅",
        description: (
          <div className="flex flex-col gap-2">
            <p>Your assignment breakdown has been added to your schedule and you earned {pointsAwarded} points!</p>
            <div className="flex gap-2">
              <Link href="/dashboard/schedule">
                <Button size="sm" variant="outline" className="w-fit bg-transparent">
                  View Schedule
                </Button>
              </Link>
              <Link href="/dashboard/assignments">
                <Button size="sm" variant="outline" className="w-fit bg-transparent">
                  View Assignments
                </Button>
              </Link>
            </div>
          </div>
        ),
        duration: 8000,
      })
    } catch (error) {
      console.error("Error adding assignment to schedule:", error)
      toast({
        title: "Error",
        description: "Failed to add assignment to schedule. Please try again.",
        variant: "destructive",
      })
    }
  }

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (!file) return

    if (file.type !== "application/pdf") {
      setError("Please upload a PDF file only.")
      return
    }

    if (file.size > 10 * 1024 * 1024) {
      setError("File size must be less than 10MB.")
      return
    }

    setError("")
    setUploadedFile(file)

    try {
      const formData = new FormData()
      formData.append("file", file)

      const response = await fetch("/api/extract-pdf", {
        method: "POST",
        body: formData,
      })

      if (response.ok) {
        const data = await response.json()
        setPdfContent(data.content)

        // Add a message about successful upload
        const uploadMessage: Message = {
          id: Date.now().toString(),
          content: `📄 Successfully uploaded "${file.name}". I can now analyze your assignment in detail!`,
          sender: "ai",
          timestamp: new Date(),
        }
        setMessages((prev) => [...prev, uploadMessage])
      } else {
        setError("Failed to process PDF file.")
      }
    } catch (error) {
      setError("Error uploading file.")
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!inputMessage.trim() || isLoading) return

    const userMessage: Message = {
      id: Date.now().toString(),
      content: inputMessage,
      sender: "user",
      timestamp: new Date(),
    }

    setMessages((prev) => [...prev, userMessage])
    setInputMessage("")
    setIsLoading(true)
    setError("")

    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          messages: [...messages, userMessage],
          pdfContent: pdfContent || undefined,
        }),
      })

      if (response.ok) {
        const data = await response.json()
        const aiMessage: Message = {
          id: (Date.now() + 1).toString(),
          content: data.content || data.message || "I apologize, but I could not generate a response.",
          sender: "ai",
          timestamp: new Date(),
        }
        setMessages((prev) => [...prev, aiMessage])

        // Check if we should add to schedule
        if (data.shouldAddToSchedule && data.assignmentInfo) {
          await addToSchedule(data.assignmentInfo)
        }
      } else {
        throw new Error("Failed to get response")
      }
    } catch (error) {
      setError("Failed to send message. Please try again.")
      console.error("Chat error:", error)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="h-screen flex flex-col max-w-4xl mx-auto">
      <Card className="flex-1 flex flex-col min-h-0">
        <CardHeader className="flex-shrink-0">
          <CardTitle className="flex items-center gap-2">
            <span>Assignment Breakdown Assistant</span>
            {uploadedFile && (
              <span className="text-sm text-green-600 bg-green-50 px-2 py-1 rounded">📄 {uploadedFile.name}</span>
            )}
          </CardTitle>
        </CardHeader>

        <CardContent className="flex-1 flex flex-col min-h-0 space-y-4">
          {/* Messages Area */}
          <div className="flex-1 overflow-y-auto space-y-4 min-h-0">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex gap-3 ${message.sender === "user" ? "justify-end" : "justify-start"}`}
              >
                {message.sender === "ai" && (
                  <Avatar className="flex-shrink-0">
                    <AvatarFallback>AI</AvatarFallback>
                  </Avatar>
                )}
                <div
                  className={`max-w-[75%] rounded-lg px-4 py-2 break-words ${
                    message.sender === "user" ? "bg-blue-500 text-white" : "bg-gray-100 text-gray-900"
                  }`}
                >
                  <div className="whitespace-pre-wrap">{message.content}</div>
                  <div className="text-xs opacity-70 mt-1">{message.timestamp.toLocaleTimeString()}</div>
                </div>
                {message.sender === "user" && (
                  <Avatar className="flex-shrink-0">
                    <AvatarFallback>You</AvatarFallback>
                  </Avatar>
                )}
              </div>
            ))}
            {isLoading && (
              <div className="flex gap-3 justify-start">
                <Avatar className="flex-shrink-0">
                  <AvatarFallback>AI</AvatarFallback>
                </Avatar>
                <div className="bg-gray-100 rounded-lg px-4 py-2">
                  <Loader2 className="h-4 w-4 animate-spin" />
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Error Display */}
          {error && (
            <Alert variant="destructive">
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          {/* Input Area */}
          <div className="flex-shrink-0 space-y-2">
            <div className="flex gap-2">
              <input ref={fileInputRef} type="file" accept=".pdf" onChange={handleFileUpload} className="hidden" />
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => fileInputRef.current?.click()}
                className="flex-shrink-0"
              >
                <Upload className="h-4 w-4 mr-2" />
                Upload PDF
              </Button>
            </div>

            <form onSubmit={handleSubmit} className="flex gap-2">
              <Input
                value={inputMessage}
                onChange={(e) => setInputMessage(e.target.value)}
                placeholder="Ask me about your assignment..."
                disabled={isLoading}
                className="flex-1 min-w-0"
              />
              <Button type="submit" disabled={isLoading || !inputMessage.trim()} className="flex-shrink-0">
                <Send className="h-4 w-4" />
              </Button>
            </form>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
