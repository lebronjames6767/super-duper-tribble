"use client"

import type React from "react"
import { useAuth } from "@/context/auth-context"
import { usePathname } from "next/navigation"

export default function ClientLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const { user, loading } = useAuth()
  const pathname = usePathname()

  // Public routes that don't require authentication
  const isPublicRoute =
    pathname === "/" || pathname === "/login" || pathname === "/signup" || pathname.startsWith("/auth/")

  // Don't apply any restrictions on public routes
  if (isPublicRoute) {
    return <>{children}</>
  }

  // Show loading state while checking authentication
  if (loading) {
    return (
      <div className="flex h-screen w-full items-center justify-center">
        <div className="h-8 w-8 animate-spin rounded-full border-b-2 border-t-2 border-primary"></div>
      </div>
    )
  }

  // Redirect to login if not authenticated and trying to access protected route
  if (!user && !isPublicRoute) {
    // Using window.location for hard redirect to avoid hydration issues
    if (typeof window !== "undefined") {
      window.location.href = "/login"
      return null
    }

    // Fallback for SSR
    return (
      <div className="flex h-screen w-full items-center justify-center">
        <p>Redirecting to login...</p>
      </div>
    )
  }

  // User is authenticated, render the children
  return <>{children}</>
}
