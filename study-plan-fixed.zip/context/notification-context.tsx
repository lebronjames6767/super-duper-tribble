"use client"

import type React from "react"
import { createContext, useContext, useState, useCallback, useEffect } from "react"
import { useAuth } from "./auth-context"

export interface Notification {
  id: string
  title: string
  message: string
  type: "deadline" | "reminder" | "achievement" | "warning" | "info"
  timestamp: string
  read: boolean
  dismissed: boolean
  actionUrl?: string
  actionText?: string
}

interface NotificationContextType {
  notifications: Notification[]
  unreadCount: number
  addNotification: (notification: Omit<Notification, "id" | "timestamp" | "read" | "dismissed">) => void
  markAsRead: (id: string) => void
  dismissNotification: (id: string) => void
  clearAllNotifications: () => void
  notifyAssignmentCreated: (assignmentName: string, deadline: Date) => void
  notifyAssignmentCompleted: (assignmentName: string, pointsEarned: number) => void
  notifyDeadlineApproaching: (assignmentName: string, hoursLeft: number) => void
  notifyGoalCompleted: (goalName: string) => void
  notifyRewardRedeemed: (rewardName: string, pointsCost: number) => void
  notifyRewardActivated: (rewardName: string, duration: string) => void
  notifyPointsEarned: (points: number, reason: string) => void
  notifyStreakAchievement: (streakDays: number) => void
}

const NotificationContext = createContext<NotificationContextType | undefined>(undefined)

export function NotificationProvider({ children }: { children: React.ReactNode }) {
  const [notifications, setNotifications] = useState<Notification[]>([])
  const { user } = useAuth()

  // Load notifications from localStorage on mount
  useEffect(() => {
    if (user) {
      const stored = localStorage.getItem(`notifications_${user.id}`)
      if (stored) {
        try {
          setNotifications(JSON.parse(stored))
        } catch (error) {
          console.error("Error loading notifications:", error)
        }
      }
    }
  }, [user])

  // Save notifications to localStorage whenever they change
  useEffect(() => {
    if (user && notifications.length > 0) {
      localStorage.setItem(`notifications_${user.id}`, JSON.stringify(notifications))
    }
  }, [notifications, user])

  const addNotification = useCallback((notification: Omit<Notification, "id" | "timestamp" | "read" | "dismissed">) => {
    const newNotification: Notification = {
      ...notification,
      id: `notification_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      timestamp: new Date().toISOString(),
      read: false,
      dismissed: false,
    }

    setNotifications((prev) => [newNotification, ...prev].slice(0, 50)) // Keep only latest 50 notifications
  }, [])

  const markAsRead = useCallback((id: string) => {
    setNotifications((prev) =>
      prev.map((notification) => (notification.id === id ? { ...notification, read: true } : notification)),
    )
  }, [])

  const dismissNotification = useCallback((id: string) => {
    setNotifications((prev) =>
      prev.map((notification) => (notification.id === id ? { ...notification, dismissed: true } : notification)),
    )
  }, [])

  const clearAllNotifications = useCallback(() => {
    setNotifications((prev) => prev.map((notification) => ({ ...notification, dismissed: true })))
  }, [])

  // Helper functions for common notification types
  const notifyAssignmentCreated = useCallback(
    (assignmentName: string, deadline: Date) => {
      addNotification({
        title: "Assignment Added! 📝",
        message: `"${assignmentName}" has been added to your schedule. Due ${deadline.toLocaleDateString()}.`,
        type: "info",
        actionUrl: "/dashboard/assignments",
        actionText: "View Assignments",
      })
    },
    [addNotification],
  )

  const notifyAssignmentCompleted = useCallback(
    (assignmentName: string, pointsEarned: number) => {
      addNotification({
        title: "Assignment Completed! 🎉",
        message: `Great job completing "${assignmentName}"! You earned ${pointsEarned} points.`,
        type: "achievement",
        actionUrl: "/dashboard/rewards",
        actionText: "View Rewards",
      })
    },
    [addNotification],
  )

  const notifyDeadlineApproaching = useCallback(
    (assignmentName: string, hoursLeft: number) => {
      const urgencyLevel = hoursLeft <= 24 ? "warning" : "reminder"
      const timeText = hoursLeft <= 24 ? `${hoursLeft} hours` : `${Math.ceil(hoursLeft / 24)} days`

      addNotification({
        title: "Deadline Approaching! ⏰",
        message: `"${assignmentName}" is due in ${timeText}. Don't forget to complete it!`,
        type: urgencyLevel,
        actionUrl: "/dashboard/schedule",
        actionText: "View Schedule",
      })
    },
    [addNotification],
  )

  const notifyGoalCompleted = useCallback(
    (goalName: string) => {
      addNotification({
        title: "Goal Achieved! 🎯",
        message: `Congratulations! You've completed your goal: "${goalName}".`,
        type: "achievement",
        actionUrl: "/dashboard/goals",
        actionText: "View Goals",
      })
    },
    [addNotification],
  )

  const notifyRewardRedeemed = useCallback(
    (rewardName: string, pointsCost: number) => {
      addNotification({
        title: "Reward Redeemed! 🎁",
        message: `You've redeemed "${rewardName}" for ${pointsCost} points. Enjoy!`,
        type: "achievement",
        actionUrl: "/dashboard/rewards",
        actionText: "View Rewards",
      })
    },
    [addNotification],
  )

  const notifyRewardActivated = useCallback(
    (rewardName: string, duration: string) => {
      addNotification({
        title: "Reward Activated! ✨",
        message: `"${rewardName}" is now active for ${duration}. Enjoy your reward time!`,
        type: "info",
        actionUrl: "/dashboard/rewards",
        actionText: "View Active Rewards",
      })
    },
    [addNotification],
  )

  const notifyPointsEarned = useCallback(
    (points: number, reason: string) => {
      addNotification({
        title: "Points Earned! 💰",
        message: `You earned ${points} points for ${reason}. Keep up the great work!`,
        type: "achievement",
        actionUrl: "/dashboard/rewards",
        actionText: "Spend Points",
      })
    },
    [addNotification],
  )

  const notifyStreakAchievement = useCallback(
    (streakDays: number) => {
      addNotification({
        title: "Streak Achievement! 🔥",
        message: `Amazing! You've maintained a ${streakDays}-day study streak. Keep it going!`,
        type: "achievement",
        actionUrl: "/dashboard/analytics",
        actionText: "View Progress",
      })
    },
    [addNotification],
  )

  const unreadCount = notifications.filter((n) => !n.read && !n.dismissed).length

  const value: NotificationContextType = {
    notifications,
    unreadCount,
    addNotification,
    markAsRead,
    dismissNotification,
    clearAllNotifications,
    notifyAssignmentCreated,
    notifyAssignmentCompleted,
    notifyDeadlineApproaching,
    notifyGoalCompleted,
    notifyRewardRedeemed,
    notifyRewardActivated,
    notifyPointsEarned,
    notifyStreakAchievement,
  }

  return <NotificationContext.Provider value={value}>{children}</NotificationContext.Provider>
}

export function useNotifications() {
  const context = useContext(NotificationContext)
  if (context === undefined) {
    throw new Error("useNotifications must be used within a NotificationProvider")
  }
  return context
}
