"use client"

import { useEffect, useRef, useState } from "react"

// Animation types for different sections
export type AnimationStyle =
  | "fade-up"
  | "fade-down"
  | "fade-left"
  | "fade-right"
  | "zoom-in"
  | "zoom-out"
  | "flip-up"
  | "bounce"
  | "rotate"
  | "slide-up"
  | "slide-down"

export function useScrollAnimation() {
  const [isVisible, setIsVisible] = useState(false)
  const ref = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true)
          observer.unobserve(entry.target)
        }
      },
      {
        root: null,
        rootMargin: "0px",
        threshold: 0.1,
      },
    )

    const currentRef = ref.current
    if (currentRef) {
      observer.observe(currentRef)
    }

    return () => {
      if (currentRef) {
        observer.unobserve(currentRef)
      }
    }
  }, [])

  return { ref, isVisible }
}

// Animation classes for different animation styles
export const getAnimationClasses = (style: AnimationStyle, isVisible: boolean): string => {
  const baseClasses = "transition-all duration-1000 ease-out"

  if (!isVisible) {
    switch (style) {
      case "fade-up":
        return `${baseClasses} opacity-0 translate-y-20`
      case "fade-down":
        return `${baseClasses} opacity-0 -translate-y-20`
      case "fade-left":
        return `${baseClasses} opacity-0 translate-x-20`
      case "fade-right":
        return `${baseClasses} opacity-0 -translate-x-20`
      case "zoom-in":
        return `${baseClasses} opacity-0 scale-90`
      case "zoom-out":
        return `${baseClasses} opacity-0 scale-110`
      case "flip-up":
        return `${baseClasses} opacity-0 rotateX-30`
      case "bounce":
        return `${baseClasses} opacity-0 translate-y-12`
      case "rotate":
        return `${baseClasses} opacity-0 rotate-12`
      case "slide-up":
        return `${baseClasses} opacity-0 translate-y-full`
      case "slide-down":
        return `${baseClasses} opacity-0 -translate-y-full`
      default:
        return `${baseClasses} opacity-0`
    }
  }

  return `${baseClasses} opacity-100 translate-x-0 translate-y-0 scale-100 rotate-0`
}
