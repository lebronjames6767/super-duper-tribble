export type Json = string | number | boolean | null | { [key: string]: Json | undefined } | Json[]

export interface Database {
  public: {
    Tables: {
      assignments: {
        Row: {
          id: string
          title: string
          description: string | null
          subject_id: string | null
          size: string
          deadline: string
          completed: boolean
          created_at: string
          user_id: string
        }
        Insert: {
          id?: string
          title: string
          description?: string | null
          subject_id?: string | null
          size: string
          deadline: string
          completed?: boolean
          created_at?: string
          user_id: string
        }
        Update: {
          id?: string
          title?: string
          description?: string | null
          subject_id?: string | null
          size?: string
          deadline?: string
          completed?: boolean
          created_at?: string
          user_id?: string
        }
      }
      subjects: {
        Row: {
          id: string
          name: string
          color: string
          created_at: string
          user_id: string
        }
        Insert: {
          id?: string
          name: string
          color: string
          created_at?: string
          user_id: string
        }
        Update: {
          id?: string
          name?: string
          color?: string
          created_at?: string
          user_id?: string
        }
      }
      tasks: {
        Row: {
          id: string
          assignment_id: string
          title: string
          description: string | null
          due_date: string
          completed: boolean
          created_at: string
          user_id: string
        }
        Insert: {
          id?: string
          assignment_id: string
          title: string
          description?: string | null
          due_date: string
          completed?: boolean
          created_at?: string
          user_id: string
        }
        Update: {
          id?: string
          assignment_id?: string
          title?: string
          description?: string | null
          due_date?: string
          completed?: boolean
          created_at?: string
          user_id?: string
        }
      }
      user_preferences: {
        Row: {
          user_id: string
          theme: string
          study_hours_per_day: number
          created_at: string
          updated_at: string
        }
        Insert: {
          user_id: string
          theme?: string
          study_hours_per_day?: number
          created_at?: string
          updated_at?: string
        }
        Update: {
          user_id?: string
          theme?: string
          study_hours_per_day?: number
          created_at?: string
          updated_at?: string
        }
      }
      user_points: {
        Row: {
          user_id: string
          points: number
          created_at: string
          updated_at: string
        }
        Insert: {
          user_id: string
          points?: number
          created_at?: string
          updated_at?: string
        }
        Update: {
          user_id?: string
          points?: number
          created_at?: string
          updated_at?: string
        }
      }
      rewards: {
        Row: {
          id: string
          name: string
          description: string
          cost: number
          created_at: string
        }
        Insert: {
          id?: string
          name: string
          description: string
          cost: number
          created_at?: string
        }
        Update: {
          id?: string
          name?: string
          description?: string
          cost?: number
          created_at?: string
        }
      }
      user_rewards: {
        Row: {
          id: string
          user_id: string
          reward_id: string
          redeemed_at: string
        }
        Insert: {
          id?: string
          user_id: string
          reward_id: string
          redeemed_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          reward_id?: string
          redeemed_at?: string
        }
      }
    }
  }
}
