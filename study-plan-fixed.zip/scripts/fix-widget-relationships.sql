-- Drop existing tables if they exist to recreate them with proper relationships
DROP TABLE IF EXISTS user_widgets CASCADE;
DROP TABLE IF EXISTS widgets CASCADE;
DROP TABLE IF EXISTS user_preferences CASCADE;

-- Create widgets table
CREATE TABLE widgets (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name VARCHAR(255) NOT NULL,
  description TEXT,
  widget_type VARCHAR(50) NOT NULL,
  icon VARCHAR(50),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create user_widgets table with explicit foreign key
CREATE TABLE user_widgets (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL,
  widget_id UUID NOT NULL,
  position INTEGER NOT NULL DEFAULT 0,
  width VARCHAR(20) NOT NULL DEFAULT 'medium',
  visible BOOLEAN NOT NULL DEFAULT true,
  settings JSONB DEFAULT '{}'::jsonb,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE,
  FOREIGN KEY (widget_id) REFERENCES widgets(id) ON DELETE CASCADE
);

-- Create user_preferences table
CREATE TABLE user_preferences (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL,
  theme VARCHAR(20) DEFAULT 'system',
  accent_color VARCHAR(20) DEFAULT 'blue',
  layout_density VARCHAR(20) DEFAULT 'comfortable',
  font_size VARCHAR(20) DEFAULT 'medium',
  animation_level VARCHAR(20) DEFAULT 'medium',
  border_radius VARCHAR(20) DEFAULT 'medium',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(user_id),
  FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE
);

-- Add RLS policies
ALTER TABLE widgets ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_widgets ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_preferences ENABLE ROW LEVEL SECURITY;

-- Create policies for widgets
CREATE POLICY "Widgets are viewable by all users" ON widgets
  FOR SELECT USING (true);

-- Create policies for user_widgets
CREATE POLICY "Users can view their own widgets" ON user_widgets
  FOR SELECT USING (auth.uid() = user_id);
  
CREATE POLICY "Users can insert their own widgets" ON user_widgets
  FOR INSERT WITH CHECK (auth.uid() = user_id);
  
CREATE POLICY "Users can update their own widgets" ON user_widgets
  FOR UPDATE USING (auth.uid() = user_id);
  
CREATE POLICY "Users can delete their own widgets" ON user_widgets
  FOR DELETE USING (auth.uid() = user_id);

-- Create policies for user_preferences
CREATE POLICY "Users can view their own preferences" ON user_preferences
  FOR SELECT USING (auth.uid() = user_id);
  
CREATE POLICY "Users can insert their own preferences" ON user_preferences
  FOR INSERT WITH CHECK (auth.uid() = user_id);
  
CREATE POLICY "Users can update their own preferences" ON user_preferences
  FOR UPDATE USING (auth.uid() = user_id);

-- Seed default widgets
INSERT INTO widgets (name, description, widget_type, icon)
VALUES 
  ('Calendar', 'Shows your upcoming deadlines and events', 'calendar', 'calendar'),
  ('Focus Timer', 'Pomodoro timer with sound notifications', 'focus-timer', 'clock'),
  ('Quote of the Day', 'Inspirational quotes for motivation', 'quote', 'quote'),
  ('Weather', 'Current weather for your location', 'weather', 'cloud'),
  ('Notes', 'Quick access to your study notes', 'notes', 'file-text'),
  ('Study Streak', 'Track your daily study streak', 'streak', 'zap'),
  ('Progress Tracker', 'Visual representation of your progress', 'progress', 'bar-chart'),
  ('Upcoming Assignments', 'List of your upcoming assignments', 'assignments', 'book');
