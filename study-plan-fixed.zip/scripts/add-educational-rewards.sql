-- Add more school-appropriate rewards
INSERT INTO public.rewards (id, name, description, cost)
VALUES 
(gen_random_uuid(), 'Study Group Session', 'Organize a study group with friends', 80),
(gen_random_uuid(), 'Library Time', 'Spend time in a quiet library environment', 40),
(gen_random_uuid(), 'Educational Video', 'Watch an educational video on your topic', 50),
(gen_random_uuid(), 'Tutoring Session', 'Schedule a tutoring session for a difficult subject', 120),
(gen_random_uuid(), 'Research Time', 'Spend time researching a topic of interest', 60),
(gen_random_uuid(), 'Book Store Visit', 'Visit a bookstore to browse educational materials', 90),
(gen_random_uuid(), 'Educational Podcast', 'Listen to an educational podcast', 45),
(gen_random_uuid(), 'Museum Visit', 'Visit a museum related to your studies', 150),
(gen_random_uuid(), 'Science Experiment', 'Conduct a fun science experiment at home', 70),
(gen_random_uuid(), 'Language Practice', 'Practice a foreign language for 30 minutes', 55),
(gen_random_uuid(), 'Educational App Time', 'Use an educational app for 30 minutes', 40),
(gen_random_uuid(), 'Skill Workshop', 'Attend a workshop to learn a new skill', 100),
(gen_random_uuid(), 'Documentary Time', 'Watch a documentary related to your studies', 65),
(gen_random_uuid(), 'Art Project', 'Work on a creative art project', 75),
(gen_random_uuid(), 'Mindfulness Break', 'Take a 15-minute mindfulness break', 30);
