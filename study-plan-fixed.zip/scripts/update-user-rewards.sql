-- Update user_rewards table to add active_until and is_used columns if they don't exist
ALTER TABLE public.user_rewards 
ADD COLUMN IF NOT EXISTS active_until TIMESTAMP WITH TIME ZONE,
ADD COLUMN IF NOT EXISTS is_used BOOLEAN DEFAULT FALSE;
